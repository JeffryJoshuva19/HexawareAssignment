﻿using OrderManagementSystem.Dao;
using OrderManagementSystem.Exceptions;
using OrderManagementSystem.Models;
using OrderManagementSystem.Util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace OrderManagementSystem.Dao
{
    public class OrderProcessor : IOrderManagementRepository
    {
        public string GetUserRole(int userId)
        {
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string query = "SELECT Role FROM Users WHERE UserId = @uid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@uid", userId);

                object result = cmd.ExecuteScalar();
                return result != null ? result.ToString() : null;
            }
        }

        public void CreateUser(User user)
        {
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string checkQuery = "SELECT COUNT(*) FROM Users WHERE UserId = @id";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@id", user.UserId);

                if ((int)checkCmd.ExecuteScalar() > 0)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"User with ID {user.UserId} already exists.");
                    Console.ResetColor();
                    return;
                }

                string query = "INSERT INTO Users (UserId, Username, Password, Role) VALUES (@id, @name, @pass, @role)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", user.UserId);
                cmd.Parameters.AddWithValue("@name", user.Username);
                cmd.Parameters.AddWithValue("@pass", user.Password);
                cmd.Parameters.AddWithValue("@role", user.Role);
                cmd.ExecuteNonQuery();
            }
        }

        public void CreateProduct(User user, Product product)
        {
            if (!user.Role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("❌ Only Admins can add products.");

            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string query = @"INSERT INTO Products 
                (ProductId, ProductName, Description, Price, QuantityInStock, Type, Brand, WarrantyPeriod, Size, Color)
                VALUES 
                (@id, @name, @desc, @price, @qty, @type, @brand, @warranty, @size, @color)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", product.ProductId);
                cmd.Parameters.AddWithValue("@name", product.ProductName);
                cmd.Parameters.AddWithValue("@desc", product.Description);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@qty", product.QuantityInStock);
                cmd.Parameters.AddWithValue("@type", product.Type);
                cmd.Parameters.AddWithValue("@brand", string.IsNullOrEmpty(product.Brand) ? DBNull.Value : (object)product.Brand);
                cmd.Parameters.AddWithValue("@warranty", product.WarrantyPeriod.HasValue ? (object)product.WarrantyPeriod.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@size", string.IsNullOrEmpty(product.Size) ? DBNull.Value : (object)product.Size);
                cmd.Parameters.AddWithValue("@color", string.IsNullOrEmpty(product.Color) ? DBNull.Value : (object)product.Color);

                cmd.ExecuteNonQuery();
            }
        }

        public void CreateOrder(User user, List<Product> products)
        {
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                // Step 1: Check if user exists
                string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE UserId = @id";
                SqlCommand checkCmd = new SqlCommand(checkUserQuery, conn);
                checkCmd.Parameters.AddWithValue("@id", user.UserId);

                if ((int)checkCmd.ExecuteScalar() == 0)
                    throw new UserNotFoundException($"❌ User with ID {user.UserId} not found. Cannot place order.");

                // Step 2: Get the user's role
                string getRoleQuery = "SELECT Role FROM Users WHERE UserId = @id";
                SqlCommand roleCmd = new SqlCommand(getRoleQuery, conn);
                roleCmd.Parameters.AddWithValue("@id", user.UserId);
                string role = (string)roleCmd.ExecuteScalar();

                if (!role.Equals("Admin", StringComparison.OrdinalIgnoreCase) && !role.Equals("User", StringComparison.OrdinalIgnoreCase))
                    throw new UnauthorizedAccessException("❌ Only registered Admin or User can place orders.");

                foreach (var product in products)
                {
                    // Step 3: Check if product exists
                    string checkProduct = "SELECT COUNT(*) FROM Products WHERE ProductId = @pid";
                    SqlCommand checkProductCmd = new SqlCommand(checkProduct, conn);
                    checkProductCmd.Parameters.AddWithValue("@pid", product.ProductId);

                    if ((int)checkProductCmd.ExecuteScalar() == 0)
                        throw new ProductNotFoundException($"❌ Product with ID {product.ProductId} does not exist.");

                    // Step 4: Insert the order
                    string orderQuery = "INSERT INTO Orders (UserId, ProductId) VALUES (@userId, @productId)";
                    SqlCommand orderCmd = new SqlCommand(orderQuery, conn);
                    orderCmd.Parameters.AddWithValue("@userId", user.UserId);
                    orderCmd.Parameters.AddWithValue("@productId", product.ProductId);
                    orderCmd.ExecuteNonQuery();
                }
            }
        }

        public void CancelOrder(int userId, int orderId)
        {
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string checkQuery = "SELECT COUNT(*) FROM Orders WHERE OrderId = @oid AND UserId = @uid";
                SqlCommand cmd = new SqlCommand(checkQuery, conn);
                cmd.Parameters.AddWithValue("@uid", userId);
                cmd.Parameters.AddWithValue("@oid", orderId);

                if ((int)cmd.ExecuteScalar() == 0)
                    throw new OrderNotFoundException("❌ Order not found or not linked to given user.");

                string delQuery = "DELETE FROM Orders WHERE OrderId = @oid";
                SqlCommand delCmd = new SqlCommand(delQuery, conn);
                delCmd.Parameters.AddWithValue("@oid", orderId);
                delCmd.ExecuteNonQuery();
            }
        }

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string query = "SELECT * FROM Products";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        ProductId = (int)reader["ProductId"],
                        ProductName = reader["ProductName"].ToString(),
                        Description = reader["Description"].ToString(),
                        Price = Convert.ToDouble(reader["Price"]),
                        QuantityInStock = (int)reader["QuantityInStock"],
                        Type = reader["Type"].ToString(),
                        Brand = reader["Brand"]?.ToString(),
                        WarrantyPeriod = reader["WarrantyPeriod"] != DBNull.Value ? (int?)reader["WarrantyPeriod"] : null,
                        Size = reader["Size"]?.ToString(),
                        Color = reader["Color"]?.ToString()
                    });
                }

                return products;
            }
        }

        public List<Product> GetOrderByUser(User user)
        {
            List<Product> products = new List<Product>();
            using (SqlConnection conn = DbConnUtil.GetConnection())
            {
                conn.Open();

                string query = @"SELECT p.* FROM Products p
                             INNER JOIN Orders o ON p.ProductId = o.ProductId
                             WHERE o.UserId = @uid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@uid", user.UserId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        ProductId = (int)reader["ProductId"],
                        ProductName = reader["ProductName"].ToString(),
                        Description = reader["Description"].ToString(),
                        Price = Convert.ToDouble(reader["Price"]),
                        QuantityInStock = (int)reader["QuantityInStock"],
                        Type = reader["Type"].ToString(),
                        Brand = reader["Brand"]?.ToString(),
                        WarrantyPeriod = reader["WarrantyPeriod"] != DBNull.Value ? (int?)reader["WarrantyPeriod"] : null,
                        Size = reader["Size"]?.ToString(),
                        Color = reader["Color"]?.ToString()
                    });
                }

                return products;
            }
        }
    }
}
