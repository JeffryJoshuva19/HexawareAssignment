﻿using OrderManagementSystem.Models;
using OrderManagementSystem.Dao;
using OrderManagementSystem.Exceptions;
using System;
using System.Collections.Generic;
//This is the main page where all the execution will be done 
//the special feature i had added is i had make some colors inthe displaying of the error include green,red and yellow
/*Create OrderManagement main class and perform following operation:
• main method to simulate the loan management system. Allow the user to interact with
the system by entering choice from menu such as "createUser", "createProduct",
"cancelOrder", "getAllProducts", "getOrderbyUser", "exit".*/

//also i had given only admin can able to add product and in case of order placement only existing id can able to order 
class Program
{
    static void Main()
    {
        var processor = new OrderProcessor();

        while (true)
        {
            Console.WriteLine("\n--- Order Management System ---");
            Console.WriteLine("1. Create User");
            Console.WriteLine("2. Create Product");
            Console.WriteLine("3. Create Order");
            Console.WriteLine("4. Cancel Order");
            Console.WriteLine("5. Get All Products");
            Console.WriteLine("6. Get Orders by User");
            Console.WriteLine("0. Exit");
            Console.Write("Enter your choice: ");
            int ch = int.Parse(Console.ReadLine());

            try
            {
                switch (ch)
                {
                    case 1:
                        Console.Write("Enter User ID: ");
                        int uid = int.Parse(Console.ReadLine());
                        Console.Write("Enter Username: ");
                        string uname = Console.ReadLine();
                        Console.Write("Enter Password: ");
                        string pwd = Console.ReadLine();
                        Console.Write("Enter Role (Admin/User): ");
                        string role = Console.ReadLine();

                        processor.CreateUser(new User(uid, uname, pwd, role));
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("User created successfully.");
                        Console.ResetColor();
                        break;

                    case 2:
                        Console.Write("Enter Admin User ID: ");
                        int aid = int.Parse(Console.ReadLine());

                        string role1 = processor.GetUserRole(aid);  // ✅ Get actual role from DB

                        if (role1 == null)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("❌ User ID not found. Cannot add product.");
                            Console.ResetColor();
                            break;
                        }

                        if (!role1.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("❌ Only Admins can add products.");
                            Console.ResetColor();
                            break;
                        }

                        // ✅ Now safely proceed as admin
                        var admin = new User(aid, "", "", role1);

                        Console.Write("Enter Product ID: ");
                        int pid = int.Parse(Console.ReadLine());

                        Console.Write("Name: ");
                        string pname = Console.ReadLine();

                        Console.Write("Description: ");
                        string desc = Console.ReadLine();

                        Console.Write("Price: ");
                        double price = double.Parse(Console.ReadLine());

                        Console.Write("Quantity: ");
                        int qty = int.Parse(Console.ReadLine());

                        Console.Write("Type (Electronics/Clothing): ");
                        string type = Console.ReadLine();

                        string brand = null, size = null, color = null;
                        int? warranty = null;

                        if (type.Equals("Electronics", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.Write("Brand: ");
                            brand = Console.ReadLine();
                            Console.Write("Warranty Period (in months): ");
                            warranty = int.Parse(Console.ReadLine());
                        }
                        else if (type.Equals("Clothing", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.Write("Size: ");
                            size = Console.ReadLine();
                            Console.Write("Color: ");
                            color = Console.ReadLine();
                        }

                        var product = new Product(pid, pname, desc, price, qty, type)
                        {
                            Brand = brand,
                            WarrantyPeriod = warranty,
                            Size = size,
                            Color = color
                        };

                        try
                        {
                            processor.CreateProduct(admin, product);
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("✅ Product added successfully.");
                        }
                        catch (Exception ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("❌ Error: " + ex.Message);
                        }
                        finally
                        {
                            Console.ResetColor();
                        }

                        break;


                    case 3:
                        Console.Write("Enter User ID: ");
                        int ouid = int.Parse(Console.ReadLine());
                        var user = new User(ouid, "", "", "User");

                        Console.Write("Enter Product ID to order: ");
                        int opid = int.Parse(Console.ReadLine());

                        var orderList = new List<Product> { new Product { ProductId = opid } };
                        processor.CreateOrder(user, orderList);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Order placed successfully.");
                        Console.ResetColor();
                        break;

                    case 4:
                        Console.Write("Enter User ID: ");
                        int cuid = int.Parse(Console.ReadLine());

                        Console.Write("Enter Order ID: ");
                        int coid = int.Parse(Console.ReadLine());

                        processor.CancelOrder(cuid, coid);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Order cancelled successfully.");
                        Console.ResetColor();
                        break;

                    case 5:
                        var products = processor.GetAllProducts();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        foreach (var p in products)
                            Console.WriteLine($"{p.ProductId} - {p.ProductName} - {p.Type}");
                        Console.ResetColor();
                        break;

                    case 6:
                        Console.Write("Enter User ID: ");
                        int guid = int.Parse(Console.ReadLine());

                        var orders = processor.GetOrderByUser(new User(guid, "", "", "User"));
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        foreach (var p in orders)
                            Console.WriteLine($"{p.ProductId} - {p.ProductName}");
                        Console.ResetColor();
                        break;

                    case 0:
                        Console.WriteLine("Exiting...");
                        return;

                    default:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Invalid choice.");
                        Console.ResetColor();
                        break;
                }
            }
            catch (UserNotFoundException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("❌ " + ex.Message);
                Console.ResetColor();
            }
            catch (ProductNotFoundException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("❌ " + ex.Message);
                Console.ResetColor();
            }
            catch (OrderNotFoundException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("❌ " + ex.Message);
                Console.ResetColor();
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Access Denied: " + ex.Message);
                Console.ResetColor();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Unexpected Error: " + ex.Message);
                Console.ResetColor();
            }
        }
    }
}
