﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagementSystem.Util
{
    public static class DbConnUtil
    {
            private static readonly string connStr = "server=LAPTOP-BA3UBJQD;Initial Catalog=OrderManagementDB;Integrated Security=True";
            public static SqlConnection GetConnection()
            {
                return new SqlConnection(connStr);
            }
        }
    
}
