﻿using entity;
using System.Collections.Generic;

namespace dao
{
    public interface IOrderDetailDAO
    {
        void AddOrderDetail(OrderDetail orderDetail);
        List<OrderDetail> GetOrderDetailsByOrderId(int orderId);
        void UpdateOrderDetailQuantity(int orderDetailId, int newQuantity);
        void ApplyDiscount(int orderDetailId, decimal discount);
    }
}
