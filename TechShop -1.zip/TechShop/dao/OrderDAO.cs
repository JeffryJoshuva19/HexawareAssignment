﻿using entity;
using exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using util;

namespace dao
{
    public class OrderDAO : IOrderDAO
    {
        public void AddOrder(Order order)
        {
            if (order == null)
                throw new IncompleteOrderException("Order cannot be null.");

            if (order.Customer == null || order.Customer.CustomerID <= 0)
                throw new IncompleteOrderException("Order must have a valid customer.");

            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status) VALUES (@cid, @date, @total, @status)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cid", order.Customer.CustomerID);
                cmd.Parameters.AddWithValue("@date", order.OrderDate);
                cmd.Parameters.AddWithValue("@total", order.TotalAmount);
                cmd.Parameters.AddWithValue("@status", order.Status);
                cmd.ExecuteNonQuery();
            }
        }
        //Managing Orders List:
        public List<Order> GetAllOrders()
        {
            List<Order> orders = new List<Order>();
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Orders";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    orders.Add(new Order
                    {
                        OrderID = (int)reader["OrderID"],
                        OrderDate = reader["OrderDate"].ToString(),
                        TotalAmount = (decimal)reader["TotalAmount"],
                        Status = reader["Status"].ToString(),
                        Customer = new Customer { CustomerID = (int)reader["CustomerID"] }
                    });
                }
            }
            return orders;
        }

        public void UpdateOrderStatus(int orderId, string status)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {

                conn.Open();
                string query = "UPDATE Orders SET Status = @status WHERE OrderID = @oid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@oid", orderId);
                cmd.ExecuteNonQuery();
            }
        }

        public void CancelOrder(int orderId)
        {
            UpdateOrderStatus(orderId, "Cancelled");
            // Inventory restock logic would go here
        }

        public decimal GetTotalSales()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT SUM(TotalAmount) FROM Orders";
                SqlCommand cmd = new SqlCommand(query, conn);
                var result = cmd.ExecuteScalar();
                return result != DBNull.Value ? (decimal)result : 0;
            }
        }
    }
}
