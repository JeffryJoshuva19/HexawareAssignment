﻿using entity;
using util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace dao
{
    public class ProductDAO : IProductDAO
    {
        public void AddProduct(Product product)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();

                // Step 1: Check for duplicates
                string checkQuery = "SELECT COUNT(*) FROM Products WHERE ProductName = @pn";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@pn", product.ProductName);
                int count = (int)checkCmd.ExecuteScalar();

                if (count > 0)
                {
                    Console.WriteLine("Product already exists. Duplicate insertion skipped.");
                }
                else
                {
                    // Step 2: Proceed to insert
                    string insertQuery = "INSERT INTO Products (ProductName, Description, Price) VALUES (@pn, @desc, @pr)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                    insertCmd.Parameters.AddWithValue("@pn", product.ProductName);
                    insertCmd.Parameters.AddWithValue("@desc", product.Description);
                    insertCmd.Parameters.AddWithValue("@pr", product.Price);

                    insertCmd.ExecuteNonQuery();
                    Console.WriteLine("Product inserted successfully.");
                }
            }


        }
        //Managing Products List:
        public List<Product> GetAllProducts()
        {
            List<Product> list = new List<Product>();
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Products";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Product
                    {
                        ProductID = (int)reader["ProductID"],
                        ProductName = reader["ProductName"].ToString(),
                        Description = reader["Description"].ToString(),
                        Price = (decimal)reader["Price"]
                    });
                }
            }
            return list;
        }

        public void UpdateProduct(Product product)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "UPDATE Products SET ProductName=@pn, Description=@desc, Price=@pr WHERE ProductID=@pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@pid", product.ProductID);
                cmd.Parameters.AddWithValue("@pn", product.ProductName);
                cmd.Parameters.AddWithValue("@desc", product.Description);
                cmd.Parameters.AddWithValue("@pr", product.Price);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteProduct(int productId)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM Products WHERE ProductID = @pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@pid", productId);
                cmd.ExecuteNonQuery();
            }
        }
        //Product Search and Retrieval:
        public List<Product> SearchProductsByName(string name)
        {
            List<Product> result = new List<Product>();
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Products WHERE ProductName LIKE @name";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", "%" + name + "%");
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new Product
                    {
                        ProductID = (int)reader["ProductID"],
                        ProductName = reader["ProductName"].ToString(),
                        Description = reader["Description"].ToString(),
                        Price = (decimal)reader["Price"]
                    });
                }
            }
            return result;
        }

    }
}
