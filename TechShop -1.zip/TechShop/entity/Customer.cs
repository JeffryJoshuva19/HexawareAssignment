﻿using System;
using System.Collections.Generic;
namespace entity
{
    public class Customer
    {
        private int customerID;
        private string firstName;
        private string lastName;
        private string email;
        private string phone;
        private string address;

        public int CustomerID { get => customerID; set => customerID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email
        {
            get => email;
            set
            {
                if (!value.Contains("@"))
                    throw new Exception("Invalid email format.");
                email = value;
            }
        }
        public string Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }

        public void GetCustomerDetails()
        {
            Console.WriteLine($"Customer ID: {CustomerID}, Name: {FirstName} {LastName}, Email: {Email}, Phone: {Phone}, Address: {Address}");
        }

        public void UpdateCustomerInfo(string newEmail, string newPhone, string newAddress)
        {
            Email = newEmail;
            Phone = newPhone;
            Address = newAddress;
        }

        public int CalculateTotalOrders(List<Order> orders)
        {
            return orders.FindAll(o => o.Customer.CustomerID == this.CustomerID).Count;
        }
    }
}