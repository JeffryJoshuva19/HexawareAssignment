﻿using System;

namespace entity
{
    public class Payment
    {
        public int PaymentID { get; set; }
        public Order Order { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public DateTime PaymentDate { get; set; }

        public void GetPaymentDetails()
        {
            Console.WriteLine($"Payment ID: {PaymentID}, Order ID: {Order.OrderID}, Amount: ₹{Amount}, Method: {PaymentMethod}, Status: {PaymentStatus}, Date: {PaymentDate}");
        }
    }
}