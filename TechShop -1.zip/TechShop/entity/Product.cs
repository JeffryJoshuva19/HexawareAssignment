﻿using System;

namespace entity
{
    public class Product
    {
        private int productID;
        private string productName;
        private string description;
        private decimal price;

        public int ProductID { get => productID; set => productID = value; }
        public string ProductName { get => productName; set => productName = value; }
        public string Description { get => description; set => description = value; }
        public decimal Price
        {
            get => price;
            set
            {
                if (value < 0)
                    throw new Exception("❌ Price cannot be negative.");
                price = value;
            }
        }

        public void GetProductDetails()
        {
            Console.WriteLine($"Product ID: {ProductID}, Name: {ProductName}, Description: {Description}, Price: {Price:C}");
        }

        public void UpdateProductInfo(string newDesc, decimal newPrice)
        {
            Description = newDesc;
            Price = newPrice;
        }
    }
}
