﻿using System;
using System.Linq;
using dao;
using entity;
using exception;

/*This is the main module where we will do the CRUD operations for each tables and also some other functionalities
 like searching a product,listing the stock,etc...

 How i had designed it is using switch cases i had asked the user to select the particular opeartiosn 
that they needed to perform like customer add,update,delete,product add etc..

 and after the each number it will do eachperformance
*/



namespace main
{
    class MainModule
    {
        static void Main()
        {
            ICustomerDAO customerDAO = new CustomerDAO();
            IProductDAO productDAO = new ProductDAO();
            IOrderDAO orderDAO = new OrderDAO();
            IOrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            IInventoryDAO inventoryDAO = new InventoryDAO();
            IPaymentDAO paymentDAO = new PaymentDAO();


            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n--- TechShop Console ---");
                //1: Customer Registration
                Console.WriteLine("1. Register Customer");
                Console.WriteLine("2. View Customers");
                //7: Customer Account Updates
                Console.WriteLine("3. Update Customer");
                Console.WriteLine("4. Delete Customer");
                //2: Product Catalog Management
                Console.WriteLine("5. Add Product");
                Console.WriteLine("6. View Products");
                Console.WriteLine("7. Update Product");
                Console.WriteLine("8. Delete Product");
                //3: Placing Customer Orders
                Console.WriteLine("9. Add Order");
                //4: Tracking Order Status
                Console.WriteLine("10. View Orders");
                Console.WriteLine("11. Update Order Status");
                Console.WriteLine("12. Cancel Order");
                Console.WriteLine("13. Add Order Detail");
                Console.WriteLine("14. View Order Details by Order ID");
                Console.WriteLine("15. Update Quantity in Order Detail");
                Console.WriteLine("16. Apply Discount in Order Detail");
                //5: Inventory Management
                Console.WriteLine("17. Add Inventory Item");
                Console.WriteLine("18. View Inventory");
                Console.WriteLine("19. Remove from Inventory");
                Console.WriteLine("20. Update Stock Quantity");
                Console.WriteLine("21. Check Product Availability");
                Console.WriteLine("22. Get Inventory Value");
                Console.WriteLine("23. List Low Stock Products");
                Console.WriteLine("24. List Out of Stock Products");
                Console.WriteLine("25. View Total Orders by Customer");
                //9: Product Search and Recommendation
                
                Console.WriteLine("26. Search Product by Name");
                //6: Sales Reporting
                Console.WriteLine("27. View Total Sales");
                //8: Payment Processing
                Console.WriteLine("28. Record Payment");
                
                Console.WriteLine("29. View All Payments");
                Console.WriteLine("30. Update Payment Status");
                Console.WriteLine("31. Exit");
                Console.Write("Choose: ");

                string choice = Console.ReadLine();
                try
                {
                    switch (choice)
                    {
                        case "1":
                            Customer c = new Customer();
                            Console.Write("First Name: "); c.FirstName = Console.ReadLine();
                            Console.Write("Last Name: "); c.LastName = Console.ReadLine();
                            Console.Write("Email: "); c.Email = Console.ReadLine();
                            Console.Write("Phone: "); c.Phone = Console.ReadLine();
                            Console.Write("Address: "); c.Address = Console.ReadLine();
                            customerDAO.AddCustomer(c);
                            Console.WriteLine("Customer added.");
                            break;

                        case "2":
                            var custList = customerDAO.GetAllCustomers();
                            foreach (var cust in custList) cust.GetCustomerDetails();
                            break;

                        case "3":
                            Console.Write("Customer ID: ");
                            int cid = int.Parse(Console.ReadLine());
                            Customer cu = new Customer { CustomerID = cid };
                            Console.Write("First Name: "); cu.FirstName = Console.ReadLine();
                            Console.Write("Last Name: "); cu.LastName = Console.ReadLine();
                            Console.Write("Email: "); cu.Email = Console.ReadLine();
                            Console.Write("Phone: "); cu.Phone = Console.ReadLine();
                            Console.Write("Address: "); cu.Address = Console.ReadLine();
                            customerDAO.UpdateCustomer(cu);
                            Console.WriteLine("Customer updated.");
                            break;

                        case "4":
                            Console.Write("Customer ID: ");
                            int delid = int.Parse(Console.ReadLine());
                            customerDAO.DeleteCustomer(delid);
                            Console.WriteLine("Customer deleted.");
                            break;

                        case "5":
                            Product p = new Product();
                            Console.Write("Product Name: "); p.ProductName = Console.ReadLine();
                            Console.Write("Description: "); p.Description = Console.ReadLine();
                            Console.Write("Price: "); p.Price = decimal.Parse(Console.ReadLine());
                            productDAO.AddProduct(p);
                            //Console.WriteLine("Product added.");
                            break;

                        case "6":
                            var prodList = productDAO.GetAllProducts();
                            foreach (var prod in prodList) prod.GetProductDetails();
                            break;

                        case "7":
                            Console.Write("Product ID: ");
                            int pid = int.Parse(Console.ReadLine());
                            Product pu = new Product { ProductID = pid };
                            Console.Write("Name: "); pu.ProductName = Console.ReadLine();
                            Console.Write("Description: "); pu.Description = Console.ReadLine();
                            Console.Write("Price: "); pu.Price = decimal.Parse(Console.ReadLine());
                            productDAO.UpdateProduct(pu);
                            Console.WriteLine("Product updated.");
                            break;

                        case "8":
                            Console.Write("Product ID to delete: ");
                            int delpid = int.Parse(Console.ReadLine());
                            productDAO.DeleteProduct(delpid);
                            Console.WriteLine("Product deleted.");
                            break;

                        case "9":
                            Order o = new Order();
                            Console.Write("Customer ID: ");
                            int custId = int.Parse(Console.ReadLine());
                            o.Customer = new Customer { CustomerID = custId };
                            o.OrderDate = DateTime.Now.ToString("yyyy-MM-dd");
                            Console.Write("Total Amount: ");
                            o.TotalAmount = decimal.Parse(Console.ReadLine());
                            o.Status = "Processing";
                            orderDAO.AddOrder(o);
                            Console.WriteLine("Order placed.");
                            break;

                        case "10":
                            var orders = orderDAO.GetAllOrders();
                            foreach (var ord in orders) ord.GetOrderDetails();
                            break;

                        case "11":
                            Console.Write("Order ID: ");
                            int oid = int.Parse(Console.ReadLine());
                            Console.Write("New Status (Processing/Shipped/Delivered): ");
                            string newStatus = Console.ReadLine();
                            orderDAO.UpdateOrderStatus(oid, newStatus);
                            Console.WriteLine("Status updated.");
                            break;

                        case "12":
                            Console.Write("Order ID to cancel: ");
                            int cancelId = int.Parse(Console.ReadLine());
                            orderDAO.CancelOrder(cancelId);
                            Console.WriteLine("Order cancelled.");
                            break;

                        case "13":
                            OrderDetail od = new OrderDetail();
                            Console.Write("Order ID: ");
                            od.Order = new Order { OrderID = int.Parse(Console.ReadLine()) };
                            Console.Write("Product ID: ");
                            od.Product = new Product { ProductID = int.Parse(Console.ReadLine()) };
                            Console.Write("Quantity: ");
                            od.Quantity = int.Parse(Console.ReadLine());
                            orderDetailDAO.AddOrderDetail(od);
                            Console.WriteLine("Order detail added.");
                            break;

                        case "14":
                            Console.Write("Order ID: ");
                            int oidd = int.Parse(Console.ReadLine());
                            var list = orderDetailDAO.GetOrderDetailsByOrderId(oidd);
                            foreach (var item in list)
                            {
                                item.AddDiscount(0);
                                item.GetOrderDetailInfo();
                            }
                            break;

                        case "15":
                            Console.Write("Order Detail ID: ");
                            int odid = int.Parse(Console.ReadLine());
                            Console.Write("New Quantity: ");
                            int newQty = int.Parse(Console.ReadLine());
                            orderDetailDAO.UpdateOrderDetailQuantity(odid, newQty);
                            Console.WriteLine("Quantity updated.");
                            break;

                        case "16":
                            Console.Write("Order Detail ID: ");
                            int dId = int.Parse(Console.ReadLine());
                            Console.Write("Discount (0 to 1): ");
                            decimal disc = decimal.Parse(Console.ReadLine());
                            orderDetailDAO.ApplyDiscount(dId, disc);
                            Console.WriteLine("Discount applied\n");
                            break;

                        case "17":
                            Console.Write("Product ID: ");
                            int invId = int.Parse(Console.ReadLine());
                            Console.Write("Quantity In Stock: ");
                            int qty = int.Parse(Console.ReadLine());
                            inventoryDAO.AddToInventory(invId, qty);
                            break;

                        case "18":
                            inventoryDAO.ListAllInventory();
                            break;

                        case "19":
                            Console.Write("Product ID: ");
                            int removeId = int.Parse(Console.ReadLine());
                            Console.Write("Quantity to Remove: ");
                            int remQty = int.Parse(Console.ReadLine());
                            inventoryDAO.RemoveFromInventory(removeId, remQty);
                            break;

                        case "20":
                            Console.Write("Product ID: ");
                            int upId = int.Parse(Console.ReadLine());
                            Console.Write("New Stock Quantity: ");
                            int newStock = int.Parse(Console.ReadLine());
                            inventoryDAO.UpdateStockQuantity(upId, newStock);
                            break;

                        case "21":
                            Console.Write("Product ID: ");
                            int chkId = int.Parse(Console.ReadLine());
                            Console.Write("Quantity to Check: ");
                            int chkQty = int.Parse(Console.ReadLine());
                            bool available = inventoryDAO.IsProductAvailable(chkId, chkQty);
                            Console.WriteLine(available ? "Available" : "Not Available");
                            break;

                        case "22":
                            decimal value = inventoryDAO.GetInventoryValue();
                            Console.WriteLine("Total Inventory Value: " + value);
                            break;

                        case "23":
                            Console.Write("Enter threshold: ");
                            int threshold = int.Parse(Console.ReadLine());
                            inventoryDAO.ListLowStockProducts(threshold);
                            break;

                        case "24":
                            inventoryDAO.ListOutOfStockProducts();
                            break;
                        case "25":
                            Console.Write("Enter Customer ID: ");
                            int customerId = int.Parse(Console.ReadLine());

                            var customer = customerDAO.GetCustomerById(customerId); // You may need to create this method
                            var allOrders = orderDAO.GetAllOrders();
                            int count = customer.CalculateTotalOrders(allOrders);
                            Console.WriteLine($"Total Orders by {customer.FirstName}: {count}");
                            break;
                        case "26":
                            Console.Write("Enter product name: ");
                            string keyword = Console.ReadLine();
                            var matches = productDAO.SearchProductsByName(keyword);
                            if (!matches.Any())
                            {
                                Console.WriteLine("Product not found");
                            }
                            else
                            {
                                foreach (var prod in matches)
                                    prod.GetProductDetails();
                            }
                            break;
                        case "27":
                            decimal totalSales = orderDAO.GetTotalSales();
                            Console.WriteLine($"Total Sales: ₹{totalSales}");
                            break;
                        
                        case "28":
                            Payment pay = new Payment();
                            Console.Write("Order ID: ");
                            pay.Order = new Order { OrderID = int.Parse(Console.ReadLine()) };
                            Console.Write("Amount: ");
                            pay.Amount = decimal.Parse(Console.ReadLine());
                            Console.Write("Payment Method: ");
                            pay.PaymentMethod = Console.ReadLine();
                            pay.PaymentStatus = "Paid";
                            pay.PaymentDate = DateTime.Now;
                            paymentDAO.RecordPayment(pay);
                            Console.WriteLine("Payment recorded.");
                            break;

                        case "29":
                            var payments = paymentDAO.GetAllPayments();
                            foreach (var pmt in payments)
                                pmt.GetPaymentDetails();
                            break;

                        case "30":
                            Console.Write("Payment ID: ");
                            int pid1 = int.Parse(Console.ReadLine());
                            Console.Write("New Status: ");
                            string status = Console.ReadLine();
                            paymentDAO.UpdatePaymentStatus(pid1, status);
                            Console.WriteLine("Payment status updated.");
                            break;

                        case "31":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid option.");
                            break;
                    }
                }
                catch (InvalidDataException ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected: " + ex.Message);
                }
            }
        }
    }
}
