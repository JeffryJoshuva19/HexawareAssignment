﻿using System.Data.SqlClient;

namespace util
{
    public static class DBConnUtil
    {
        private static readonly string connStr = "server=LAPTOP-BA3UBJQD;Initial Catalog=TechShop;Integrated Security=True";
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connStr);
        }
    }
}