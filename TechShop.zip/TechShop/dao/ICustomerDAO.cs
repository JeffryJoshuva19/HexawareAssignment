﻿using entity;
using System.Collections.Generic;

namespace dao
{
    public interface ICustomerDAO
    {
        void AddCustomer(Customer customer);
        List<Customer> GetAllCustomers();
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(int customerId);

        Customer GetCustomerById(int id);
    }
}
