﻿using System;

namespace dao
{
    public interface IInventoryDAO
    {
        void AddToInventory(int productId, int quantity);
        void RemoveFromInventory(int productId, int quantity);
        void UpdateStockQuantity(int productId, int newQuantity);
        bool IsProductAvailable(int productId, int quantityToCheck);
        decimal GetInventoryValue();
        void ListLowStockProducts(int threshold);
        void ListOutOfStockProducts();
        void ListAllInventory();
    }
}