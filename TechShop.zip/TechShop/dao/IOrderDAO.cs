﻿using entity;
using System.Collections.Generic;

namespace dao
{
    public interface IOrderDAO
    {
        void AddOrder(Order order);
        List<Order> GetAllOrders();
        void UpdateOrderStatus(int orderId, string status);
        void CancelOrder(int orderId);
        decimal GetTotalSales();
    }
}