﻿using System.Collections.Generic;
using entity;

namespace dao
{
    public interface IPaymentDAO
    {
        void RecordPayment(Payment payment);
        List<Payment> GetAllPayments();
        void UpdatePaymentStatus(int paymentId, string status);
        Payment GetPaymentByOrderId(int orderId);
    }
}