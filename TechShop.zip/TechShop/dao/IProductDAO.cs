﻿using entity;
using System.Collections.Generic;

namespace dao
{
    public interface IProductDAO
    {
        void AddProduct(Product product);
        List<Product> GetAllProducts();
        void UpdateProduct(Product product);
        void DeleteProduct(int productId);
        List<Product> SearchProductsByName(string name);
    
}
}