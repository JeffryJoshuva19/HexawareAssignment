﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using entity;
using util;

namespace dao
{
    public class InventoryDAO : IInventoryDAO
    {
        //Duplicate Product Handling:
        public void AddToInventory(int productId, int quantity)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = @"IF EXISTS (SELECT 1 FROM Inventory WHERE ProductID = @pid)
                                  UPDATE Inventory SET QuantityInStock += @qty, LastStockUpdate = GETDATE() WHERE ProductID = @pid
                                  ELSE
                                  INSERT INTO Inventory (ProductID, QuantityInStock, LastStockUpdate) VALUES (@pid, @qty, GETDATE())";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@pid", productId);
                cmd.Parameters.AddWithValue("@qty", quantity);
                cmd.ExecuteNonQuery();
            }
        }

        public void RemoveFromInventory(int productId, int quantity)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string checkQuery = "SELECT QuantityInStock FROM Inventory WHERE ProductID = @pid";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@pid", productId);
                int currentQty = (int)checkCmd.ExecuteScalar();

                if (currentQty < quantity)
                    throw new InvalidOperationException("Insufficient stock.");

                string updateQuery = "UPDATE Inventory SET QuantityInStock -= @qty, LastStockUpdate = GETDATE() WHERE ProductID = @pid";
                SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                updateCmd.Parameters.AddWithValue("@qty", quantity);
                updateCmd.Parameters.AddWithValue("@pid", productId);
                updateCmd.ExecuteNonQuery();
            }
        }
        //Handling Inventory Updates:
        public void UpdateStockQuantity(int productId, int newQuantity)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "UPDATE Inventory SET QuantityInStock = @qty, LastStockUpdate = GETDATE() WHERE ProductID = @pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@qty", newQuantity);
                cmd.Parameters.AddWithValue("@pid", productId);
                cmd.ExecuteNonQuery();
            }
        }

        public bool IsProductAvailable(int productId, int quantityToCheck)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT QuantityInStock FROM Inventory WHERE ProductID = @pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@pid", productId);
                var result = cmd.ExecuteScalar();
                if (result == null) return false;
                return (int)result >= quantityToCheck;
            }
        }

        public decimal GetInventoryValue()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = @"SELECT SUM(i.QuantityInStock * p.Price) FROM Inventory i JOIN Products p ON i.ProductID = p.ProductID";
                SqlCommand cmd = new SqlCommand(query, conn);
                var result = cmd.ExecuteScalar();
                return result != DBNull.Value ? (decimal)result : 0;
            }
        }

        public void ListLowStockProducts(int threshold)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = @"SELECT p.ProductName, i.QuantityInStock FROM Inventory i
                                 JOIN Products p ON i.ProductID = p.ProductID
                                 WHERE i.QuantityInStock < @threshold";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@threshold", threshold);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine($" Low Stock: {reader["ProductName"]} - Qty: {reader["QuantityInStock"]}");
                }
            }
        }

        public void ListOutOfStockProducts()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = @"SELECT p.ProductName FROM Inventory i
                                 JOIN Products p ON i.ProductID = p.ProductID
                                 WHERE i.QuantityInStock = 0";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine($" Out of Stock: {reader["ProductName"]}");
                }
            }
        }
        //Inventory Management with SortedList:
        public void ListAllInventory()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = @"SELECT p.ProductName, i.QuantityInStock, i.LastStockUpdate
                                 FROM Inventory i JOIN Products p ON i.ProductID = p.ProductID";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine($" {reader["ProductName"]} - Qty: {reader["QuantityInStock"]}, Last Updated: {reader["LastStockUpdate"]}");
                }
            }
        }
    }
}
