﻿using entity;
using exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using util;

namespace dao
{
    public class OrderDetailDAO : IOrderDetailDAO
    {
        public void AddOrderDetail(OrderDetail orderDetail)
        {
            if (orderDetail == null || orderDetail.Product == null || orderDetail.Product.ProductID <= 0)
                throw new IncompleteOrderException("Order detail must reference a valid product.");
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO OrderDetails (OrderID, ProductID, Quantity) VALUES (@oid, @pid, @qty)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@oid", orderDetail.Order.OrderID);
                cmd.Parameters.AddWithValue("@pid", orderDetail.Product.ProductID);
                cmd.Parameters.AddWithValue("@qty", orderDetail.Quantity);
                cmd.ExecuteNonQuery();
            }
        }

        public List<OrderDetail> GetOrderDetailsByOrderId(int orderId)
        {
            List<OrderDetail> list = new List<OrderDetail>();
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT od.OrderDetailID, od.Quantity, p.ProductID, p.ProductName, p.Price FROM OrderDetails od JOIN Products p ON od.ProductID = p.ProductID WHERE od.OrderID = @oid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@oid", orderId);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    OrderDetail od = new OrderDetail
                    {
                        OrderDetailID = (int)reader["OrderDetailID"],
                        Quantity = (int)reader["Quantity"],
                        Product = new Product
                        {
                            ProductID = (int)reader["ProductID"],
                            ProductName = reader["ProductName"].ToString(),
                            Price = (decimal)reader["Price"]
                        }
                    };
                    list.Add(od);
                }
            }
            return list;
        }

        public void UpdateOrderDetailQuantity(int orderDetailId, int newQuantity)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "UPDATE OrderDetails SET Quantity = @qty WHERE OrderDetailID = @odid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@qty", newQuantity);
                cmd.Parameters.AddWithValue("@odid", orderDetailId);
                cmd.ExecuteNonQuery();
            }
        }

        public void ApplyDiscount(int orderDetailId, decimal discount)
        {
            // Only applied in memory; to persist discount you'd need to add a Discount column to the DB
            Console.WriteLine($"(Note: Discount of {discount * 100}% applied in memory only for OrderDetailID {orderDetailId})");
        }
    }
}
