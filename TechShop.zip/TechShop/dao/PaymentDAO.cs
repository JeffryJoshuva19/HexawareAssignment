﻿using entity;
using exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using util;

namespace dao
{
    public class PaymentDAO : IPaymentDAO
    {
        public void RecordPayment(Payment payment)
        {
            if (payment == null)
                throw new PaymentFailedException("Payment data cannot be null.");

            if (payment.Amount <= 0)
                throw new PaymentFailedException("Invalid payment amount. Must be greater than 0.");

            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO Payments (OrderID, Amount, PaymentMethod, PaymentStatus, PaymentDate) VALUES (@oid, @amt, @method, @status, @date)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@oid", payment.Order.OrderID);
                cmd.Parameters.AddWithValue("@amt", payment.Amount);
                cmd.Parameters.AddWithValue("@method", payment.PaymentMethod);
                cmd.Parameters.AddWithValue("@status", payment.PaymentStatus);
                cmd.Parameters.AddWithValue("@date", payment.PaymentDate);
                cmd.ExecuteNonQuery();
            }
        }
        //Payment Records List:
        public List<Payment> GetAllPayments()
        {
            List<Payment> list = new List<Payment>();
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Payments";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Payment
                    {
                        PaymentID = (int)reader["PaymentID"],
                        Order = new Order { OrderID = (int)reader["OrderID"] },
                        Amount = (decimal)reader["Amount"],
                        PaymentMethod = reader["PaymentMethod"].ToString(),
                        PaymentStatus = reader["PaymentStatus"].ToString(),
                        PaymentDate = (DateTime)reader["PaymentDate"]
                    });
                }
            }
            return list;
        }

        public void UpdatePaymentStatus(int paymentId, string status)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "UPDATE Payments SET PaymentStatus = @status WHERE PaymentID = @pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@pid", paymentId);
                cmd.ExecuteNonQuery();
            }
        }
        //Payment Records List:
        public Payment GetPaymentByOrderId(int orderId)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM Payments WHERE OrderID = @oid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@oid", orderId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new Payment
                    {
                        PaymentID = (int)reader["PaymentID"],
                        Order = new Order { OrderID = (int)reader["OrderID"] },
                        Amount = (decimal)reader["Amount"],
                        PaymentMethod = reader["PaymentMethod"].ToString(),
                        PaymentStatus = reader["PaymentStatus"].ToString(),
                        PaymentDate = (DateTime)reader["PaymentDate"]
                    };
                }
                return null;
            }
        }
    }
}
