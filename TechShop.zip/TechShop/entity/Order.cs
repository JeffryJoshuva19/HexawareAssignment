﻿using System;
using entity;

namespace entity
{
    public class Order
    {
        private int orderID;
        private Customer customer;
        private string orderDate;
        private decimal totalAmount;
        private string status;

        public int OrderID { get => orderID; set => orderID = value; }
        public Customer Customer { get => customer; set => customer = value; }
        public string OrderDate { get => orderDate; set => orderDate = value; }
        public decimal TotalAmount { get => totalAmount; set => totalAmount = value; }
        public string Status { get => status; set => status = value; }

        public void GetOrderDetails()
        {
            Console.WriteLine($"Order ID: {OrderID}, Date: {OrderDate}, Customer ID: {Customer.CustomerID}, Total: {TotalAmount:C}, Status: {Status}");
        }

        public void CalculateTotalAmount(decimal[] subtotals)
        {
            decimal total = 0;
            foreach (var s in subtotals)
                total += s;
            TotalAmount = total;
        }

        public void UpdateOrderStatus(string newStatus)
        {
            Status = newStatus;
        }

        public void CancelOrder()
        {
            Status = "Cancelled";
        }
    }
}