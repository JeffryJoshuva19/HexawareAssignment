﻿using System;

namespace entity
{
    public class OrderDetail
    {
        private int orderDetailID;
        private Order order;
        private Product product;
        private int quantity;
        private decimal discount;

        public int OrderDetailID { get => orderDetailID; set => orderDetailID = value; }
        public Order Order { get => order; set => order = value; }
        public Product Product { get => product; set => product = value; }
        public int Quantity
        {
            get => quantity;
            set
            {
                if (value < 1)
                    throw new Exception("Quantity must be at least 1");
                quantity = value;
            }
        }
        public decimal Discount { get => discount; set => discount = value; }

        public decimal CalculateSubtotal()
        {
            decimal baseAmount = Product.Price * Quantity;
            decimal discountedAmount = baseAmount - (baseAmount * Discount);
            return discountedAmount;
        }

        public void GetOrderDetailInfo()
        {
            Console.WriteLine($"OrderDetail ID: {OrderDetailID}, Product: {Product.ProductName}, Quantity: {Quantity}, Discount: {Discount * 100}%, Subtotal: {CalculateSubtotal():C}");
        }

        public void UpdateQuantity(int newQty)
        {
            Quantity = newQty;
        }

        public void AddDiscount(decimal percentage)
        {
            if (percentage < 0 || percentage > 1)
                throw new Exception("Discount must be between 0 and 1");
            Discount = percentage;
        }
    }
}
